
import { Headphones } from 'lucide-react';
console.log(Headphones ? "Headphones imported" : "Headphones missing");
